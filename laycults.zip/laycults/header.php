<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="header.css">
    <link rel="stylesheet" type="text/css" href="footer.css">
    <link rel="stylesheet" type="text/css" href="estilo.css">
	<link rel="stylesheet" type="text/css" href="agregar.css">
	<link rel="stylesheet" href="style.css">
	<link rel="icon" href="img/uocra.png">

	<title>UOCRA-Código Azul</title>
</head>
<body>
<script> type="text/javasscript"src="script.js"</script>
	<header class="header1">
		<img class="banner"  src="img/logohospital.png">
		<h1>U.O.C.R.A EMERGENCIA</h1>

		<a href="index.php" class="logo"></a>	
		<div>
			<a href="index.php">INICIO</a>
			<a href="LOGGIN/index.html" >EMERGENCIAS</a>
			<a href="LOGGIN/index1.html">DATOS PERSONALES</a>
			
		</div>
	</header>