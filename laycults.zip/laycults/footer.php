</main>
       <!--::::Pie de Pagina::::::-->
    <footer>
     "U.O.C.R.A Emergencias"<br> Derechos Reservados por:<br> Romero Leonardo Facundo <br> Fernandez Luque Liz <br> Ojeda Ovidio  &copy; 2022 <br>
    
    <img class="logo" src="img/uocra.png" alt="">

    </footer>
        <!--::::Pie de Pagina::::::-->
</body>
</html>