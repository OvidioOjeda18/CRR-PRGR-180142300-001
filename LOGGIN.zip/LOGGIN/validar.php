<?php
include('db.php');
$usuario=$_POST['usuario'];
$password=$_POST['password'];
$usuario1=$_POST['usuario'];
$password1=$_POST['password'];



$consulta="SELECT*FROM usuario where usuario='$usuario' and password='$password'";
$consulta1="SELECT*FROM admi where usuario='$usuario1' and password='$password1'";
$resultado=mysqli_query($conexion,$consulta);
$resultado1=mysqli_query($conexion,$consulta1);

$filas=mysqli_num_rows($resultado);
$filas1=mysqli_num_rows($resultado1);
  if($filas){
    
    header("location:../emergencias.php");
  }
  if($filas1){
    
  header("location:../codigo.php");

  }
  else{

    include("index.html");
mysqli_free_result($resultado);
mysqli_free_result($resultado1);
mysqli_close($conexion);

  }
?>
 <h1 class="bad">ERROR DE AUTENTIFICACION</h1>