<?php

$conexion=mysqli_connect("localhost","root","","olimp")or die(
    "error de conexion");
?>