<?php
include('db.php');
$usuario=$_POST['usuario'];
$password=$_POST['password'];



$consulta="SELECT*FROM usuario where usuario='$usuario' and password='$password'";

$resultado=mysqli_query($conexion,$consulta);

$filas=mysqli_num_rows($resultado);

  if($filas){
    
    header("location:../estadisticas.php");
  }


  else{

    include("index.html");
mysqli_free_result($resultado);
mysqli_close($conexion);

  }
?>
 <h1 class="bad">ERROR DE AUTENTIFICACION</h1>